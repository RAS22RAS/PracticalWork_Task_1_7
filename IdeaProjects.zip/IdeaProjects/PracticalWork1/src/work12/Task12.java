package work12;
import java.util.Scanner;
public class Task12 {
  public static void main(String[] args){
    Scanner scan=new Scanner(System.in);
    System.out.print("Input your name  "  );
    String inputLine=scan.next();
    System.out.println("My name is " + inputLine );
}
}
