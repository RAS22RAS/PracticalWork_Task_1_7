package work11;

public class Task11 {
    public static void main(String[] args){
        System.out.println("Hello Students!");
    }
}
