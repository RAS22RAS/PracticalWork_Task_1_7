package work54;
import java.util.Scanner;
public class Task54 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Text1");
        String str1=sc.nextLine();
        str1=str1.trim();

        System.out.println("Input Text2");
        String str2=sc.nextLine();
        str2=str2.trim();


        String tmpStr="";
        String outResult="";
        int j=0;
        while ( j < str1.length()){
            tmpStr=String.valueOf(str1.charAt(j));
           if (str2.indexOf(tmpStr) == -1) {
           outResult=outResult+tmpStr;
            }

         j++;
        }

        //Выводим результат
        System.out.println("OutText=" + outResult);

    }
}
