package work53;
import java.util.Arrays;
import java.util.Scanner;
public class Task53 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Text");
        String str=sc.nextLine();
        str=str.trim();

        //Выводим введенный текст если фраза состоит из одного слова
        if (str.indexOf(" ")==-1) {
            System.out.println("InputText=OutText=" + str);
            return  ;
        }


        //Выводим результат
        int indFirstWord=str.indexOf(" ");
        int indLastWord=str.lastIndexOf(" ");
        System.out.println("OutText=" + str.substring(indLastWord).trim() + " " + str.substring(indFirstWord,indLastWord).trim() + " " + str.substring(0,indFirstWord).trim());

        }
    }

