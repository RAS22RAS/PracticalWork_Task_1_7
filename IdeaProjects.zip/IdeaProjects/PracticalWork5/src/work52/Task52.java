package work52;

import java.util.Scanner;

public class Task52 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Text");
        String str=sc.nextLine();
        str=str.trim();

        int j=0;
        String tmpStr="";
        String abbrStr="";
        while (j<str.length()){

            if ( String.valueOf(str.charAt(j)).equals(" ") &&  !tmpStr.equals("") ) {
                abbrStr=abbrStr+tmpStr.charAt(0);  //Формируем очередную букву аббревиатуры
                tmpStr="";  //Обнуляем  tmpStr

            } else if ( String.valueOf(str.charAt(j)).equals(" ") &&  tmpStr.equals("") ) { //Предусматриваем что может быть подряд несколько пробелов
                //Ничего не делаем, и преходим к следующему номеру счетчика j
            } else{  //Формируем текущее слово из которого потом в конце получим первую букву
                tmpStr=tmpStr+str.charAt(j);
                tmpStr=tmpStr.trim();  //Выполняем trim (на всякий случай, хуже  не будет)
            }
            System.out.println("tmpStr for Debug = " + tmpStr); //Для визуализации как происходит накопление
          j++;
        }

        //После выхода из цикла осталось обработать последнее слово записанное в tmpStr, которое в цикле не обработали
        abbrStr=abbrStr+tmpStr.charAt(0); //Формируем последнюю букву аббревиатуры


        //Выводим полученную аббревиатуру
        System.out.println("Abbreviated=" + abbrStr.toUpperCase());
    }
}
