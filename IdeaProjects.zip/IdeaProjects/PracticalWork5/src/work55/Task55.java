package work55;
import java.util.Scanner;
public class Task55 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Text1");
        String str1=sc.nextLine();
        str1=str1.trim();

        String tmpChar="";
        int indFirst=0;
        int indLast=0;
        String outResult="";
        int j=0;

        while ( j < str1.length()){
            tmpChar=String.valueOf(str1.charAt(j));
            indFirst=str1.indexOf(tmpChar);
            indLast=str1.lastIndexOf(tmpChar);

            //Debug
            //System.out.println("indFirst=" + indFirst);
           //System.out.println("indLast=" + indLast);
            if (indFirst==indLast) {
                outResult=outResult+tmpChar;
            }

            j++;
        }

        //Выводим результат
        System.out.println("OutText=" + outResult);
    }
}

