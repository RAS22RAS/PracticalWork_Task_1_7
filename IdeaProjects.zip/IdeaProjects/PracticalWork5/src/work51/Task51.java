package work51;

import java.util.Scanner;

public class Task51 {

    public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
    System.out.println("Input Text");
    String str=sc.nextLine();

        //Обрабатываем случай когда строка из одного символа  или пустая строка
        if (str.length() < 2) {
            System.out.println("Half phrase not sence, input has one char or Null string: " + str );
            return;
        }

        int lenHalf=str.length()/2;  //Получаем индекс середины текста

        //Обрабатываем случай когда в тексте одно слово (нет пробелов), тогда безусловно делим пополам
        if (str.indexOf(" ")==-1) {
            System.out.println( "Formal Half phrase(word has not space)=" + str.substring(0,lenHalf) );
            return;
        }

        //Если в тексте есть пробелы, то делим тект пополам красиво.. чтобы слово которое посередине текста не разрывалось
        // То есть , если середина текста попадает внутрь слова - то  продвигаемся вперед пока не встретим пробел или конец строки
        System.out.println("Full phrase=" + str.substring(0,str.length())  );
        System.out.println("Formal Half phrase=" + str.substring(0,lenHalf)  );
       //char value1=str.charAt(lenHalf);
       String str1= String.valueOf(str.charAt(lenHalf-1));
    if ( !str1.equals(" ")) {
        int j = 0;
        String str2=String.valueOf(str.charAt(lenHalf-1+j));
        System.out.println("Char on formal half position=" + str2);
        System.out.println("index on formal half position=" + lenHalf);
        while (!str2.equals(" ") && lenHalf+j < str.length()) { //Проходим цикл до ближайшего пробела (вперед) или до конца строки
            System.out.println("Debug print=" +str.substring(0,lenHalf + j));
            j++;
            str2=String.valueOf(str.charAt(lenHalf-1+j));
        }
           System.out.println("Debug print=" +str.substring(0,lenHalf + j));
        if (lenHalf+j==str.length()){
            System.out.println("Smart Half Phrase=" + str.substring(0,lenHalf + j).trim());
        } else{
            System.out.println("Smart Half Phrase=" + str.substring(0,lenHalf + j-1).trim());
              }


    }else{
            System.out.println("Smart Half Phrase=" + str.substring(0,lenHalf).trim());

        }

    }
}
