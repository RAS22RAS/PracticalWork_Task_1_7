package work32;

import java.util.Scanner;

public class Task32 {
    public static void main(String[] args){
        Scanner scan=new Scanner(System.in);
        System.out.print("Input month numbers "  );
        int inputMonth=scan.nextInt();

        System.out.println("");
        System.out.print("Input Procent "  );
        float inputProcent=scan.nextFloat();

        System.out.println("");
        System.out.print("Input begin summ "  );
        float inputSumm=scan.nextFloat();

        float summAll=inputSumm;
                int i=inputMonth;
        while (i > 0) {
            summAll=summAll*(1+inputProcent/100);
            i--;
        }

        System.out.println("Total Summ after " + inputMonth + " is " + summAll );

    }
}
