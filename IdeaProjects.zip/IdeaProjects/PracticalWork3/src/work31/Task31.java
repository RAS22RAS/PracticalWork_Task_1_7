package work31;

import java.util.Scanner;

public class Task31 {

    public static void main(String[] args) {
	// write your code here
        final float funtToGramm=453.6F;
        Scanner scan=new Scanner(System.in);
        System.out.print("Input weight in funt "  );
        float inputFunt=scan.nextFloat();
      float wInGrammTotal=inputFunt*funtToGramm;

      int wInKg=(int)(wInGrammTotal/1000);
      float   wInGramm=wInGrammTotal-wInKg*1000;
        System.out.println("");
        System.out.println("weight in Kg=" + wInKg ) ;
        System.out.println("weight in Gramm=" + wInGramm ) ;
    }
}
