package work33;

import java.util.Scanner;

public class Task33 {
    public static void main(String[] args){
        Scanner  scan = new Scanner(System.in);

        System.out.print("Input firstCost "  );
        float firstCost=scan.nextFloat();

        System.out.println("");
        System.out.print("Input firstChangeProcent "  );
        float firstChangeProcent = scan.nextFloat();

        System.out.println("");
        System.out.print("Input secondChangeProcent "  );
        float secondChangeProcent = scan.nextFloat();

        float Cost1 = firstCost + firstCost * firstChangeProcent / 100;
        float Cost2 = Cost1 + Cost1 * secondChangeProcent / 100;

        float finalCost = Cost2;

        System.out.println("");
        System.out.println("Final Cost is " + finalCost);

    }
}
