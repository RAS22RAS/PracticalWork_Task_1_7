package work42;
import java.util.Scanner;
public class Task42 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input int value");
        int xx=sc.nextInt();
        String tmpStr;
       switch (xx) {
           case 1 : tmpStr="Один"; break;
           case 2 : tmpStr="Два"; break;
           case 3 : tmpStr="Три"; break;
           case 4 : tmpStr="Четыре"; break;
           case 5 : tmpStr="Пять"; break;
           case 6 : tmpStr="Шесть"; break;
           case 7 : tmpStr="Семь"; break;
           case 8 : tmpStr="Восемь"; break;
           case 9 : tmpStr="Девять"; break;
           default: tmpStr="Другое";
       }
        //Выводим результат  первого способа  решения задачи
        System.out.println("Output1=" + tmpStr);

       if (xx==1) {
           tmpStr="Один";
       } else if (xx==2) {
           tmpStr="Два";
        } else if (xx==3) {
           tmpStr="Три";
       } else if (xx==4) {
           tmpStr="Четыре";
       } else if (xx==5) {
           tmpStr="Пять";
       } else if (xx==6) {
           tmpStr="Шесть";
       } else if (xx==7) {
           tmpStr="Семь";
       } else if (xx==8) {
           tmpStr="Восемь";
       } else if (xx==9) {
           tmpStr="Девять";
       } else {
           tmpStr="Другое";
       }

        //Выводим результат  второго способа  решения задачи
        System.out.println("Output2=" + tmpStr);
    }
}
