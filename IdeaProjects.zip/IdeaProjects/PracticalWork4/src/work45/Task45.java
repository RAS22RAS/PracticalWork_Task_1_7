package work45;

public class Task45 {

    public static void main(String[] args) {

        System.out.println("Таблица умножения");

        System.out.println("* |  1  2  3  4  5  6  7  8  9");
        int i=0;
        while(i < 9){
            i++;
            int j=0;
            String tmpStr=i + " |";
                    while (j < 9){
                        j++;
                        if (i*j > 9) {
                            tmpStr=tmpStr + " " + i*j;
                        } else {
                            tmpStr=tmpStr + "  " + i*j;
                        }


                    }
            System.out.println(tmpStr);
        }
    }

}
