package work44;
import java.util.Scanner;
public class Task44 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Вводим диапазон [1..x] в пределах которого находим числа которые кратны трем или четырем
        // [1..x]
        System.out.println("введите число для определения диапазона поиска первых 10 чисел кратных трем или четырем");
        int x=sc.nextInt();
        int i = 0;
        int ii = 1;

        System.out.print("Первые 10 чисел кратных трем или четырем из интервала [1.." + x + "]= ");
        while(ii <= x){

            if (ii%3==0 || ii%4==0) {
                System.out.print(ii + " ");
                i++;
            }

            if (i==10) {
                break;
            }

            ii++;
        }
    }



}
