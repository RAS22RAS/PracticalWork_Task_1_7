package work46;
import java.util.Scanner;
public class Task46 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Вводим число для которого  будем искать сумму квадратов его цифр
        System.out.println("введите число для  которого  будем искать сумму квадратов его цифр");
        int x=sc.nextInt();

        int absX;

        //'Получаем модуль числа'
        if (x < 0) {
            absX=-x;
        } else {
            absX=x;
        }

        //Находим сумму квадратов цифр для absX
        int summ=0;
        int r;
        while (absX > 0) {

                    if (absX > 9) {
                        r=absX%10;
                        summ=summ+r*r;
                        absX=absX-r;
                        absX=absX/10;
                    } else{
                        summ=summ+absX*absX;
                        absX=0;
                    }

        }
        System.out.println("для числа " + x + " сумма квадратов его цифр=" + summ);
    }
}
