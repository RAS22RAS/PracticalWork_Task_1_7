package work43;
public class Task43 {

    public static void main(String[] args) {
        int i=0;
        String tmpStr="";
        while (i<8 ) {
            i++;
        tmpStr=i+ " " + tmpStr;
            System.out.println(tmpStr);
        }
    }
}
