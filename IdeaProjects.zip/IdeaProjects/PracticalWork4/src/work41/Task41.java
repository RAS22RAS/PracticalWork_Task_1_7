package work41;

import java.util.Scanner;

public class Task41 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input a");
        Double a=sc.nextDouble();

        System.out.println("Input b");
        Double b=sc.nextDouble();

        System.out.println("Input c");
        Double c=sc.nextDouble();

        Double max;

        if (a>=b) {
           max=a;
        } else {
           max=b;
        }

        if (c> max) {
            max=c;
        } else {
            ;
        }

        //Выводим результат
        System.out.println("MAX=" + max);
    }

}
