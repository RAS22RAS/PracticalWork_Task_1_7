package work24;
import java.util.Scanner;
public class Task24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите   целое число > 0");

        int intNumber=sc.nextInt();

        if (intNumber < 0 ) {
            System.out.println("введено отрицательное число , выход .... ");
            return;
        }


        //Находим количество цифр введенного числа
        int i=0;
        int tmp;
        tmp=intNumber;
        while (tmp > 0) {

            if (tmp > 9) {
               tmp=tmp/10;

            } else {
                tmp=0;
            }
          i++;
        }

        System.out.println("Кол-во цифр введенного числа .... " + i );

        //Теперь находим число состоящее из цифр наоборот
        int reorderNumber=0;
        int intNumberTmp=intNumber;
        int j;
        int r;
        for (j=i-1; j>=0; j--) {
          if(intNumberTmp > 9){
              r=intNumberTmp%10;
              int tmpPower=1;
              for (int k=1;k<=j;k++){tmpPower=10*tmpPower;}
              reorderNumber=r*tmpPower+reorderNumber;
              intNumberTmp=(intNumberTmp-r)/10;
          } else {
              reorderNumber=reorderNumber+intNumberTmp;
          }
        }

        System.out.println("Число из цифр в обратном порядке = " + reorderNumber );

        System.out.println("Разность между полученным и введенным числом = " + (reorderNumber-intNumber) );
    }



}
