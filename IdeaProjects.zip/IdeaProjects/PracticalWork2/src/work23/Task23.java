package work23;
import java.util.Scanner;
public class Task23 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите  первое целое число ");
        int tmp1=sc.nextInt();

        System.out.println("Введите  второе целое число ");
        int tmp2=sc.nextInt();

        tmp1=tmp1+tmp2;
        tmp2=tmp1-tmp2;
        tmp1=tmp1-tmp2;


        System.out.println("измененное первое число " + tmp1 );
        System.out.println("измененное второе число " + tmp2 );
    }
}
