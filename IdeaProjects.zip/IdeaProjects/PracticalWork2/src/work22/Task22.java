package work22;
import java.text.SimpleDateFormat;
public class Task22 {

    public static void main(String[] args) {


        System.out.print("Выводим  системную дату , в миллисекундах (от начала 1970 года) = "  );
        Long tmpResult=System.currentTimeMillis();
        System.out.println(tmpResult);

        System.out.print("Выводим  системную дату в понятном виде = "  );
        SimpleDateFormat formating = new SimpleDateFormat("YYYY:MM:dd:HH:mm:ss:SSS");
        System.out.println( formating.format(tmpResult) );
    }

}
