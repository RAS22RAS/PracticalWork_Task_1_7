package work21;
import java.util.Scanner;
public class Task21 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите кол-во недель для которых найдем кол-во секунд");
        int weekNumber=sc.nextInt();

        System.out.println("кол-во секунд в " + weekNumber + " неделях =" + weekNumber*7*24*60*60 );

    }

}
