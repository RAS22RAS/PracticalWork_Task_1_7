package work71;
import java.util.Arrays;
import java.util.Scanner;
public class Task71 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input array dimension as int value > 0");
        int inputSize=sc.nextInt();

        int[] array=createArray(inputSize);
        System.out.println("Array=" + Arrays.toString(array));
    }

    public static int[] createArray(int size){
    int[] arrayTmp= new int[size];

            int j=2;
     for(int i=0; i<arrayTmp.length; i++){
        arrayTmp[i]=j;
        j+=2;
     }
    return arrayTmp;
    }
}
