package work73;
//import java.util.Arrays;
import java.util.Scanner;
public class Task73 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Matrix size as int value > 0");
        int iSize=sc.nextInt();

        int[][] MyMatrix=createMatrix(iSize);
        System.out.println("====New Matrix has been created====");


        System.out.println("Output MyMatrix=");
        printMatrix(MyMatrix);
    }

    public static int[][] createMatrix(int size){
        int[][] MatrixTmp = new int[size][size];


        for(int j=0; j< MatrixTmp.length; j++){
            for (int i=0;i< MatrixTmp.length ;i++){
                MatrixTmp[i][j]=i+size*j+1;
            }
        }
        return MatrixTmp;
    }

    public static void printMatrix(int[][] varMatrix){
        if(varMatrix==null){
        System.out.println("matrix is null");
        return;
        }

     for (int[] line : varMatrix){
         if (line==null || line.length==0){
             System.out.println("line is null") ;
             return;
         }

         for (int member : line){
             System.out.print(member);
             System.out.print(" ");
             //System.out.printf(" %d", member);
         }
         System.out.println();
     }
    }
}
