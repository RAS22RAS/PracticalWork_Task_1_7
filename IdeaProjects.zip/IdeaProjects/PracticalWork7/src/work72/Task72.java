package work72;
import java.util.Arrays;
import java.util.Scanner;
public class Task72 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input array dimension as int value > 0");
        int iSize=sc.nextInt();

        int[] array=createArray(iSize);
        System.out.println("Array has been created=" + Arrays.toString(array));

        int sumOdd=sumOddElementsArray(array);
        System.out.println("odd sum in my array=" + sumOdd);
    }


    public static int sumOddElementsArray(int[] array){

        if (array==null || array.length==0){
            return -1;
        }

        int tmpSum=0;
        for (int i=0 ; i<array.length ; i++) {
         if (i%2== 0) {
         tmpSum+=array[i];
         }
        }

        return tmpSum;
    }

    public static int[] createArray(int size){
        int[] arrayTmp= new int[size];


        for(int i=0; i< arrayTmp.length; i++){
            arrayTmp[i]=(int) Math.abs((Math.random() *100));
        }

        return arrayTmp;
    }
}
