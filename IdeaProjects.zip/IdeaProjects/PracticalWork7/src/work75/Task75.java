package work75;
import java.util.Arrays;
import java.util.Scanner;
import java.lang.String;
public class Task75 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input string contains number only {0,1,2,3,4,5,6,7,8,9}");
        String inputString=sc.nextLine();

        int[] ResultArray=countOfSequenceNumbers(inputString);
        System.out.println("Result Sequence Array = " + Arrays.toString(ResultArray));
    }

    public static int[] countOfSequenceNumbers(String varStr){
      int[]  tmpArray = new int[10];
      String stringChar;
     for (int i=0 ; i < varStr.length() ; i++) {
         char tmpChar=varStr.charAt(i);
         //Добавляем 1 в соотв элемент массива только если анализируемый символ -цифра
         if (tmpChar >='0' && tmpChar <='9' ){
             int tmpToNumber=Integer.valueOf(String.valueOf(varStr.charAt(i)));
             if (tmpToNumber >= 0) {
                 tmpArray[tmpToNumber]+=1;
             }
         } else {
             //Если в строке есть символы отличные от цифр то они будут игнорироваться, выдавать ошибку не будем
             //System.out.println("Error , Input string must contains number only {0,1,2,3,4,5,6,7,8,9}");
         }
     }
     return tmpArray;
    }


}
