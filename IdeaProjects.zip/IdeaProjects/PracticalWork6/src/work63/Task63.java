package work63;

import java.util.Scanner;

public class Task63 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input string");
        String inputStr=sc.nextLine();

        System.out.println("Input word number  in string");
        int inputWordNumber=sc.nextInt();


        String result=getFirstCharacterOfWord(inputStr,inputWordNumber);

        //Выводим результат
        System.out.println("result=" + result);
    }

    public static String getFirstCharacterOfWord (String Str, int wordNumber ){
        int j=0;
        int wordCounter=0;
        String wordTmp="";
        String trimStr;
        trimStr=Str.trim();
        while (j<trimStr.length()) {
                   //trimStr.charAt(j+1) не вызовет ошибку так как  выполнили trim для  исходной строки trimStr=Str.trim()
                    if ( String.valueOf(trimStr.charAt(j)).equals(" ") && !String.valueOf(trimStr.charAt(j+1)).equals(" ") ) {
                        wordCounter=wordCounter+1;
                        if (wordCounter==wordNumber){
                         break;
                        } else {
                            wordTmp="";
                        }
                    }
                    else{ wordTmp=wordTmp+trimStr.charAt(j);

                    }
               j++;

        }
        if (j==trimStr.length()) {
            wordCounter=wordCounter+1;
        }
        //Debug
        //System.out.println("wordTmp=" + wordTmp);
        //System.out.println("wordCounter=" + wordCounter);
        if (wordCounter < wordNumber) {
            return "" + "Фраза содержит меньше слов чем введенное число слов";
        } else {
            return "" + wordTmp.charAt(0);
        }

    }


}
