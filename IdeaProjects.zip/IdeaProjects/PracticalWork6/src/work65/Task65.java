package work65;
import java.util.Scanner;
public class Task65 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input high value > 0");
        int inputH=sc.nextInt();

        String result=printPyramid(inputH);
        System.out.println("Creating Pyramid is " + result);
    }

    public static String  printPyramid(int H){
       int i=1;
        //String str1="";
        //String str2="";

       while  ( i<=H ) {
           int j=1;
           String str1="";
           String str2="";
        while (j<2*H){
          if (j<i) {
                str1=str1+j;
                str2=str2+(i-j);
            } else {
              str1=" "  + str1;
              str2=str2 + " " ;
            }

          j++;
        }
           System.out.println(str1+i+str2);
           i++;
       }

        return "Done";
    }

}
