package work61;
import java.util.Scanner;
public class Task61 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input a");
        Double a=sc.nextDouble();

        System.out.println("Input b");
        Double b=sc.nextDouble();

        System.out.println("Input c");
        Double c=sc.nextDouble();


        Double S=areaTriangle(a,b,c);

        //Выводим результат
        System.out.println("S=" + S);
    }


    public static double  areaTriangle (double a , double b , double c){
        Double p=(a+b+c)/2;
        Double S=Math.sqrt( p*(p-a)*(p-b)*(p-c));
        return S;
    }


}
