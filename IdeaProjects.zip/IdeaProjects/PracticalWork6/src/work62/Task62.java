package work62;
import java.util.Scanner;
public class Task62 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input a");
        int inputDigit=sc.nextInt();




        String result=latestDigit(inputDigit);

        //Выводим результат
        System.out.println("result=" + result);
    }

    public static String latestDigit (int inDigit ){
        if (inDigit >-10 && inDigit <10) {
            return "NoResult";
        }
        String strTmp=String.valueOf(inDigit);
        return ""+ strTmp.charAt(strTmp.length()-1)+strTmp.charAt(strTmp.length()-2);
    }

}
