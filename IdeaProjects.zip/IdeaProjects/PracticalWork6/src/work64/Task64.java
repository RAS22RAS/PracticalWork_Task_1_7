package work64;

import java.util.Scanner;

public class Task64 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Input integer value");
        int inputInt=sc.nextInt();

        String result=convertDecimalToBinary(inputInt);
        System.out.println("Output binary value=" + result);
    }


    public static String  convertDecimalToBinary(int number){
        String strFull="";
        int tmpInt=number;

        if (tmpInt < 2) {
            strFull="" + tmpInt;
            return strFull;
        }

        while (tmpInt >= 2) {
                strFull=tmpInt%2+strFull;
                tmpInt=(tmpInt-(tmpInt%2))/2;
            }
        strFull=tmpInt+strFull;
    return strFull;

    }

}
